import Link from 'next/link';
import { SiteHeader } from '@/components/SiteHeader';

/* Placeholder. The real Home page is built after the second approval. */
export default function Page() {
  return (
    <>
      <SiteHeader current="/" />
      <main id="main" className="wrap section">
        <div className="stack">
          <span className="badge badge--example">Placeholder</span>
          <h1>Gridlock</h1>
          <p>The design system is ready for review. Pages come after approval.</p>
          <Link className="btn" href="/styleguide/">Open the styleguide</Link>
        </div>
      </main>
    </>
  );
}
