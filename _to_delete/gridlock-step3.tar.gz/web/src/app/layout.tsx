import type { Metadata, Viewport } from 'next';
import localFont from 'next/font/local';
import { ToastProvider } from '@/components/Toast';
import '@/styles/tokens.css';
import '@/styles/base.css';
import '@/styles/components.css';

const anton = localFont({ src: '../fonts/anton-latin-400-normal.woff2', weight: '400', variable: '--font-anton', display: 'swap', adjustFontFallback: 'Arial' });
const barlow = localFont({
  src: [
    { path: '../fonts/barlow-latin-400-normal.woff2', weight: '400' },
    { path: '../fonts/barlow-latin-500-normal.woff2', weight: '500' },
    { path: '../fonts/barlow-latin-700-normal.woff2', weight: '700' },
  ],
  variable: '--font-barlow',
  display: 'swap',
  adjustFontFallback: 'Arial',
});
const spaceMono = localFont({
  src: [
    { path: '../fonts/space-mono-latin-400-normal.woff2', weight: '400' },
    { path: '../fonts/space-mono-latin-700-normal.woff2', weight: '700' },
  ],
  variable: '--font-space-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Gridlock: styleguide',
  description: 'Internal design system for Gridlock, an original comic-style car card collection.',
  robots: { index: false, follow: false },
};
export const viewport: Viewport = { themeColor: '#0b0b0c', colorScheme: 'dark', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${anton.variable} ${barlow.variable} ${spaceMono.variable}`}>
      <body>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
